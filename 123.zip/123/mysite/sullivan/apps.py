from django.apps import AppConfig


class SullivanConfig(AppConfig):
    name = 'sullivan'
